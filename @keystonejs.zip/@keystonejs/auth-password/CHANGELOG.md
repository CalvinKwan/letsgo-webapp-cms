# @keystonejs/auth-password

## 6.1.2

### Patch Changes

- [#95](https://github.com/keystonejs/keystone-5/pull/95) [`c8ff78b95`](https://github.com/keystonejs/keystone-5/commit/c8ff78b95af5d56d44bbc11c51e7cf28b81323b4) Thanks [@bladey](https://github.com/bladey)! - Renamed branch `master` to `main`.

- Updated dependencies [[`c8ff78b95`](https://github.com/keystonejs/keystone-5/commit/c8ff78b95af5d56d44bbc11c51e7cf28b81323b4)]:
  - @keystonejs/fields@22.1.3
  - @keystonejs/session@8.3.2

## 6.1.1

### Patch Changes

- [#95](https://github.com/keystonejs/keystone-5/pull/95) [`a890b0576`](https://github.com/keystonejs/keystone-5/commit/a890b057628b60c2d1870cc3f5afd8e87b03f7df) Thanks [@bladey](https://github.com/bladey)! - Renamed branch `master` to `main`.

- Updated dependencies [[`a890b0576`](https://github.com/keystonejs/keystone-5/commit/a890b057628b60c2d1870cc3f5afd8e87b03f7df)]:
  - @keystonejs/fields@22.1.2
  - @keystonejs/session@8.3.1

## 6.1.0

### Minor Changes

- [`345a5f0f6`](https://github.com/keystonejs/keystone-5/commit/345a5f0f66a34c75696230ad2fcfb7a2eac86cb4) [#23](https://github.com/keystonejs/keystone-5/pull/23) Thanks [@bladey](https://github.com/bladey)! - Keystone 5 is now in a 6 to 12 month active maintenance phase, packages will no longer have active development releases. For more information please read our Keystone 5 and beyond post located here - https://github.com/keystonejs/keystone-5/issues/21

### Patch Changes

- Updated dependencies [[`345a5f0f6`](https://github.com/keystonejs/keystone-5/commit/345a5f0f66a34c75696230ad2fcfb7a2eac86cb4)]:
  - @keystonejs/fields@22.1.0
  - @keystonejs/session@8.3.0

## 6.0.2

### Patch Changes

- [`04bf1e4bb`](https://github.com/keystonejs/keystone-5/commit/04bf1e4bb0223f4e2e06664bbc9e95c51118eb84) [#2](https://github.com/keystonejs/keystone-5/pull/2) Thanks [@bladey](https://github.com/bladey)! - Updated repository URL in package.json.

- Updated dependencies [[`04bf1e4bb`](https://github.com/keystonejs/keystone-5/commit/04bf1e4bb0223f4e2e06664bbc9e95c51118eb84)]:
  - @keystonejs/fields@22.0.1
  - @keystonejs/session@8.2.1

## 6.0.1

### Patch Changes

- Updated dependencies [[`b97216a65`](https://github.com/keystonejs/keystone-5/commit/b97216a6526fffcca8232d86b115c28cb19587bf), [`4035218df`](https://github.com/keystonejs/keystone-5/commit/4035218df390beff3d42c0d3fc21335230d8a60d), [`8d0be8a89`](https://github.com/keystonejs/keystone-5/commit/8d0be8a89e2d9b89826365f81f47b8d8863b93d0)]:
  - @keystonejs/fields@22.0.0

## 6.0.0

### Major Changes

- [`0dfb63414`](https://github.com/keystonejs/keystone-5/commit/0dfb6341412c3c7ae60f069d37fa96e0c9adc900) [#4304](https://github.com/keystonejs/keystone-5/pull/4304) Thanks [@timleslie](https://github.com/timleslie)! - Changed the default value of [`protectIdentities`](https://www.keystonejs.com/keystonejs/auth-password/#config) from `false` to `true`.
  To keep the current behaviour you can explicitly pass through the value you want, e.g.

  ```
  keystone.createAuthStrategy({
    type: PasswordAuthStrategy,
    list: 'User',
    config: { protectIdentities: true },
  });
  ```

## 5.1.18

### Patch Changes

- Updated dependencies [[`364ac9254`](https://github.com/keystonejs/keystone-5/commit/364ac9254735befd2d4804789bb62464bb51ee5b), [`841be0bc9`](https://github.com/keystonejs/keystone-5/commit/841be0bc9d192cf64399231a543a9ba9ff41b9a0)]:
  - @keystonejs/fields@21.0.0

## 5.1.17

### Patch Changes

- Updated dependencies [[`a5e40e6c4`](https://github.com/keystonejs/keystone-5/commit/a5e40e6c4af1ab38cc2079a0f6e27d39d6b7d546), [`2d660b2a1`](https://github.com/keystonejs/keystone-5/commit/2d660b2a1dd013787e022cad3a0c70dbe08c60da)]:
  - @keystonejs/fields@20.0.0

## 5.1.16

### Patch Changes

- Updated dependencies [[`e5efd0ef3`](https://github.com/keystonejs/keystone-5/commit/e5efd0ef3d6943534cb6c728afe5dbf0caf43e74)]:
  - @keystonejs/fields@19.0.0

## 5.1.15

### Patch Changes

- Updated dependencies [[`a02e69987`](https://github.com/keystonejs/keystone-5/commit/a02e69987902cfde38d820e68cb24b7a20ca1f6f), [`f70c9f1ba`](https://github.com/keystonejs/keystone-5/commit/f70c9f1ba7452b54a15ab71943a3777d5b6dade4)]:
  - @keystonejs/fields@18.0.0

## 5.1.14

### Patch Changes

- Updated dependencies [[`d38c9174f`](https://github.com/keystonejs/keystone-5/commit/d38c9174f8146ad6e268be87cf5d54d5074bc593), [`e8b2e4772`](https://github.com/keystonejs/keystone-5/commit/e8b2e477206acffb143f19fb14be1e3b4cd0eb91)]:
  - @keystonejs/fields@17.0.0

## 5.1.13

### Patch Changes

- Updated dependencies [[`d38a41f25`](https://github.com/keystonejs/keystone-5/commit/d38a41f25a1b4c90c05d2fb85116dc385d4ee77a), [`5ede731fc`](https://github.com/keystonejs/keystone-5/commit/5ede731fc58a79e7322b852bdd2d971ece45281e), [`f8d4b175b`](https://github.com/keystonejs/keystone-5/commit/f8d4b175bbc29962569acb24b34c29c44b61791f), [`1d9068770`](https://github.com/keystonejs/keystone-5/commit/1d9068770d03658954044c530e56e66169667e25), [`694f3acfb`](https://github.com/keystonejs/keystone-5/commit/694f3acfb9faa78aebfcf48cf711165560f16ff7), [`149d6fd6f`](https://github.com/keystonejs/keystone-5/commit/149d6fd6ff057c17570346063c173376769dcc79), [`e44102e9f`](https://github.com/keystonejs/keystone-5/commit/e44102e9f7f770b1528d642d763ccf9f88f3cbb1)]:
  - @keystonejs/fields@16.0.0
  - @keystonejs/session@8.1.0

## 5.1.12

### Patch Changes

- Updated dependencies [[`af5171563`](https://github.com/keystonejs/keystone-5/commit/af51715637433bcdd2538835c98ac71a8eb86122), [`086b6baec`](https://github.com/keystonejs/keystone-5/commit/086b6baecdb8730bd7ae7001a96ae881fb13bac2), [`7da9d67d7`](https://github.com/keystonejs/keystone-5/commit/7da9d67d7d481c44a81406c6b34540a3f0a8340d), [`086b6baec`](https://github.com/keystonejs/keystone-5/commit/086b6baecdb8730bd7ae7001a96ae881fb13bac2), [`c3883e01c`](https://github.com/keystonejs/keystone-5/commit/c3883e01c01b83cf5938de9bebf2dd68f4861364), [`fd2b8d1cf`](https://github.com/keystonejs/keystone-5/commit/fd2b8d1cf0b23b177951d65006a0d0faf666a5d6)]:
  - @keystonejs/fields@15.0.0

## 5.1.11

### Patch Changes

- Updated dependencies [[`e710cd445`](https://github.com/keystonejs/keystone-5/commit/e710cd445bfb71317ca38622cc3795da61d13dff), [`136cb505c`](https://github.com/keystonejs/keystone-5/commit/136cb505ce11931de7fc470debe438e335588781), [`4b95d8a46`](https://github.com/keystonejs/keystone-5/commit/4b95d8a46d53d32b2873e350716311441cd37262), [`e63b9f25a`](https://github.com/keystonejs/keystone-5/commit/e63b9f25adb64cecf0f65c6f97fe30c95e483996), [`5fc97cbf4`](https://github.com/keystonejs/keystone-5/commit/5fc97cbf4489587a3a8cb38c04ba81fc2cb1fc5a), [`0cbb7e7b0`](https://github.com/keystonejs/keystone-5/commit/0cbb7e7b096c2a99685631a601fce7273d03cc70), [`51aef1ef0`](https://github.com/keystonejs/keystone-5/commit/51aef1ef06a89422e89a6118b7820848d5970669)]:
  - @keystonejs/session@8.0.0
  - @keystonejs/fields@14.0.0

## 5.1.10

### Patch Changes

- Updated dependencies [[`c235e34c7`](https://github.com/keystonejs/keystone-5/commit/c235e34c7a72cd05b05b3d1af08c93c1e98a8e91), [`b693b2fa8`](https://github.com/keystonejs/keystone-5/commit/b693b2fa8a391d7f5bcfbea11061679bd4b559d8)]:
  - @keystonejs/fields@13.0.0

## 5.1.9

### Patch Changes

- [`b5f89b305`](https://github.com/keystonejs/keystone-5/commit/b5f89b305eb8aaf63c3afc9f45f7aa7e4ce3f7b7) [#2993](https://github.com/keystonejs/keystone-5/pull/2993) Thanks [@jesstelford](https://github.com/jesstelford)! - Correct the config docs; the options are `identityField` & `secretField`.

* [`c1e6e6ff3`](https://github.com/keystonejs/keystone-5/commit/c1e6e6ff374fbac71535da0cc2badde0c13569e2) [#3051](https://github.com/keystonejs/keystone-5/pull/3051) Thanks [@mikehazell](https://github.com/mikehazell)! - Made simulated password self-documenting.

* Updated dependencies [[`c2ebb51c7`](https://github.com/keystonejs/keystone-5/commit/c2ebb51c786297879fe9fac2007804055631e9e2), [`c3faeeff4`](https://github.com/keystonejs/keystone-5/commit/c3faeeff41f9b29a9fc31ca4e7778b596fcb20b9), [`397982096`](https://github.com/keystonejs/keystone-5/commit/39798209642571d3ba698e11410f5161cd1943bb), [`538378e4e`](https://github.com/keystonejs/keystone-5/commit/538378e4eb143dbe6e7a943408e0af302eb86b85), [`9f67e0e91`](https://github.com/keystonejs/keystone-5/commit/9f67e0e912b4f7dcb90fcb07c4b30bd6c45de464), [`ea9608342`](https://github.com/keystonejs/keystone-5/commit/ea960834262cec66f52fa39c1b3b07b702b3cd4d), [`8fddd97b2`](https://github.com/keystonejs/keystone-5/commit/8fddd97b20f1928ff7306d5d0dcc96e58ffe55fb), [`fdfb01417`](https://github.com/keystonejs/keystone-5/commit/fdfb01417b6d330342f4b6c326767c9567e35ca5), [`83548d43d`](https://github.com/keystonejs/keystone-5/commit/83548d43d661959a34a6de475994430ee1de3a1d), [`5ea313461`](https://github.com/keystonejs/keystone-5/commit/5ea313461aa2cba310b2634cc87780092c84b5be), [`aacc4a7f8`](https://github.com/keystonejs/keystone-5/commit/aacc4a7f8f88c242ae4bd784330d25056842d3fb), [`04c57fa78`](https://github.com/keystonejs/keystone-5/commit/04c57fa7840714d3413e093d468b78d740c95c9a), [`f33388b50`](https://github.com/keystonejs/keystone-5/commit/f33388b5061d59747ab46e238f43e9b08f52bd1e), [`4b06157be`](https://github.com/keystonejs/keystone-5/commit/4b06157be6cffde2d88969823f7c410fefd82317), [`649017fbd`](https://github.com/keystonejs/keystone-5/commit/649017fbd5ea17c36e8c49d44836e1f2bcae2692), [`170faf568`](https://github.com/keystonejs/keystone-5/commit/170faf568fef5b74147791476b466dc7a25c7d6f), [`de27d2c16`](https://github.com/keystonejs/keystone-5/commit/de27d2c16b520ae5126a74efb85c70ae88ae6b60)]:
  - @keystonejs/fields@12.0.0

## 5.1.8

### Patch Changes

- Updated dependencies [[`a124417f`](https://github.com/keystonejs/keystone-5/commit/a124417fddc75889db5e4e8e0d5625fb4af12590), [`54931d75`](https://github.com/keystonejs/keystone-5/commit/54931d75d3f26f4f300c2c4c3ee65ed3183b4a6a), [`e9a0de2c`](https://github.com/keystonejs/keystone-5/commit/e9a0de2cc03c211beca01ec206244105bdca6afc), [`59ed6310`](https://github.com/keystonejs/keystone-5/commit/59ed6310bacc76f571639de048689becbedbeac5)]:
  - @keystonejs/fields@11.0.0

## 5.1.7

### Patch Changes

- [`2a1e4f49`](https://github.com/keystonejs/keystone-5/commit/2a1e4f49d7f234c49e5b04440ff786ddf3e9e7ed) [#2901](https://github.com/keystonejs/keystone-5/pull/2901) Thanks [@Vultraz](https://github.com/Vultraz)! - Fixed Admin UI sometimes using the wrong auth mutation name.

- Updated dependencies [[`72e0a4e1`](https://github.com/keystonejs/keystone-5/commit/72e0a4e19942df11c72d11c2cf6ee9bc94300d87), [`5ec4e5d5`](https://github.com/keystonejs/keystone-5/commit/5ec4e5d547503baeae2ac2f6317b66c2ebae93b7), [`6e507838`](https://github.com/keystonejs/keystone-5/commit/6e5078380e1d17eb2884554eef114fdd521a15f4), [`0fbc5b98`](https://github.com/keystonejs/keystone-5/commit/0fbc5b989a9f96248d1bd7f2f589fe77cb1d8f7d), [`e3d46ce4`](https://github.com/keystonejs/keystone-5/commit/e3d46ce4bd9f9ec8808ab3194672c6849e624e27), [`d8584765`](https://github.com/keystonejs/keystone-5/commit/d85847652e224e5000e036be2df0b8a45ab96385), [`da1359df`](https://github.com/keystonejs/keystone-5/commit/da1359dfc1bff7e27505eff876efe3a0865bae2d), [`285026a0`](https://github.com/keystonejs/keystone-5/commit/285026a04ffce23ab72d7defc18ced2e980b0de4), [`d4811b02`](https://github.com/keystonejs/keystone-5/commit/d4811b0231c5d64e95dbbce57531df0931d4defa), [`e2800875`](https://github.com/keystonejs/keystone-5/commit/e28008756cbcc1e07e012a9fdb0cfa0ad94f3673), [`60e2c7eb`](https://github.com/keystonejs/keystone-5/commit/60e2c7eb2298a016c68a19a056040a3b45beab2a), [`99da34a8`](https://github.com/keystonejs/keystone-5/commit/99da34a8db26b8861b08cee330407605e787a80c), [`bcf03a7f`](https://github.com/keystonejs/keystone-5/commit/bcf03a7f8067a3f29f22dde397b957bf5cee1a07), [`e765ad20`](https://github.com/keystonejs/keystone-5/commit/e765ad20abae9838f64b72b7d43767ec87db336a), [`d7eb2601`](https://github.com/keystonejs/keystone-5/commit/d7eb260144d2aa31e7ef4e636e7a23f91dc37285)]:
  - @keystonejs/fields@10.0.0
  - @keystonejs/session@7.0.0

## 5.1.6

### Patch Changes

- [`885bc678`](https://github.com/keystonejs/keystone-5/commit/885bc6786dd63cad86515b2fe6a39ea52b39d4c0) [#2313](https://github.com/keystonejs/keystone-5/pull/2313) Thanks [@gautamsi](https://github.com/gautamsi)! - Fixed password authentication failure message when there is no password set.

- Updated dependencies [[`c013d8bc`](https://github.com/keystonejs/keystone-5/commit/c013d8bc1113b2a31ededc3918ab98c2c99f25f4), [`93ae77ef`](https://github.com/keystonejs/keystone-5/commit/93ae77efe71151279a15ddb7ddc3df60651022b4), [`eb90aea6`](https://github.com/keystonejs/keystone-5/commit/eb90aea6b33dda8d95baba818306328dd747247f)]:
  - @keystonejs/fields@9.0.1

## 5.1.5

### Patch Changes

- Updated dependencies [[`fd685241`](https://github.com/keystonejs/keystone-5/commit/fd68524135025e4d800b4a98932916736dd50e9d)]:
  - @keystonejs/fields@9.0.0

## 5.1.4

### Patch Changes

- [`c08c28d2`](https://github.com/keystonejs/keystone-5/commit/c08c28d22f2c6a2bfa73ab0ea347c9e0da8a9063) [#2593](https://github.com/keystonejs/keystone-5/pull/2593) Thanks [@jossmac](https://github.com/jossmac)! - Applied a more consistent voice throughout documentation.

- Updated dependencies [[`e7e4bc1d`](https://github.com/keystonejs/keystone-5/commit/e7e4bc1d22149d4daceb31d303f6ad10c2b853ba), [`58c4ffc3`](https://github.com/keystonejs/keystone-5/commit/58c4ffc3d4b1edf8bdfbc4ea299133d303239fc6), [`007063c4`](https://github.com/keystonejs/keystone-5/commit/007063c4f17e6e7038312ed9126eaf91757e7939), [`c08c28d2`](https://github.com/keystonejs/keystone-5/commit/c08c28d22f2c6a2bfa73ab0ea347c9e0da8a9063), [`d138736d`](https://github.com/keystonejs/keystone-5/commit/d138736db184c5884171c7a65e43377f248046b5), [`2ae2bd47`](https://github.com/keystonejs/keystone-5/commit/2ae2bd47eb54a816cfd4c8cd178c460729cbc258), [`2cbd38b0`](https://github.com/keystonejs/keystone-5/commit/2cbd38b05adc98cface11a8767f66b48a1cb0bbf)]:
  - @keystonejs/fields@8.0.0
  - @keystonejs/session@6.0.1

## 5.1.3

### Patch Changes

- Updated dependencies [[`b6a555c2`](https://github.com/keystonejs/keystone-5/commit/b6a555c28296394908757f7404b72bc6b828b52a), [`68be8f45`](https://github.com/keystonejs/keystone-5/commit/68be8f452909100fbddec431d6fe60c20a06a700), [`61a70503`](https://github.com/keystonejs/keystone-5/commit/61a70503f6c184a8f0f5440466399f12e6d7fa41)]:
  - @keystonejs/session@6.0.0
  - @keystonejs/fields@7.0.2

## 5.1.2

### Patch Changes

- Updated dependencies [[`161bf3e5`](https://github.com/keystonejs/keystone-5/commit/161bf3e57acb1b3d88a0836507d4c8dd4935f260)]:
  - @keystonejs/fields@7.0.0

## 5.1.1

### Patch Changes

- [`5ba330b8`](https://github.com/keystonejs/keystone-5/commit/5ba330b8b2609ea0033a636daf9a215a5a192c20) [#2487](https://github.com/keystonejs/keystone-5/pull/2487) Thanks [@Noviny](https://github.com/Noviny)! - Small changes to package.json (mostly adding a repository field)

- Updated dependencies [[`fe42a997`](https://github.com/keystonejs/keystone-5/commit/fe42a997c81825a819ac28f05e02d1ed61099542), [`6b353eff`](https://github.com/keystonejs/keystone-5/commit/6b353effc8b617137a3978b2c845e01403889722), [`5ba330b8`](https://github.com/keystonejs/keystone-5/commit/5ba330b8b2609ea0033a636daf9a215a5a192c20)]:
  - @keystonejs/fields@6.3.2
  - @keystonejs/session@5.1.1

## 5.1.0

### Minor Changes

- [`517b23e4`](https://github.com/keystonejs/keystone-5/commit/517b23e4b17414ed1807e8d7af1e67377ba3b7bf) [#2391](https://github.com/keystonejs/keystone-5/pull/2391) Thanks [@timleslie](https://github.com/timleslie)! - Removed support for Node 8.x, as it is [no longer in maintenance mode](https://nodejs.org/en/about/releases/).

### Patch Changes

- Updated dependencies [[`517b23e4`](https://github.com/keystonejs/keystone-5/commit/517b23e4b17414ed1807e8d7af1e67377ba3b7bf)]:
  - @keystonejs/fields@6.3.0
  - @keystonejs/session@5.1.0

## 5.0.2

### Patch Changes

- [`2ed5404c`](https://github.com/keystonejs/keystone-5/commit/2ed5404cafd11faeb7a06bd0ef4c65d62a9e27b0) [#2280](https://github.com/keystonejs/keystone-5/pull/2280) - Refactor code internals to make code paths clearer.

## 5.0.1

### Patch Changes

- Updated dependencies [[`267dab2f`](https://github.com/keystonejs/keystone-5/commit/267dab2fee5bbea711c417c13366862e8e0ab3be), [`8188d76c`](https://github.com/keystonejs/keystone-5/commit/8188d76cb3f5d3e112ef95fd4e1887db9a520d9d), [`af1e9e4d`](https://github.com/keystonejs/keystone-5/commit/af1e9e4d3b74753b903b20641b51df99184793df), [`946a52fd`](https://github.com/keystonejs/keystone-5/commit/946a52fd7057bb73f4ffd465ef51498172926866), [`ee6fbcb2`](https://github.com/keystonejs/keystone-5/commit/ee6fbcb264a640f58332c50a2f502a4380c0d071), [`0145f7e2`](https://github.com/keystonejs/keystone-5/commit/0145f7e21d9297e3037c709587eb3b4220ba3f01), [`2cc83b12`](https://github.com/keystonejs/keystone-5/commit/2cc83b12be757019ba25658139478e8f5b2b19c6), [`a1dcbd7b`](https://github.com/keystonejs/keystone-5/commit/a1dcbd7bd7448fdcacbfe9fb0196bfee3c4a5326), [`6a348b93`](https://github.com/keystonejs/keystone-5/commit/6a348b93607c305c4ba61c1406a4acd508f33f64)]:
  - @keystonejs/fields@6.0.0

## 5.0.0

### Major Changes

- [`7b4ed362`](https://github.com/keystonejs/keystone-5/commit/7b4ed3623f5774d7783c39962bfa1ce97938e310) [#1821](https://github.com/keystonejs/keystone-5/pull/1821) Thanks [@jesstelford](https://github.com/jesstelford)! - Release @keystonejs/\* packages (つ＾ ◡ ＾)つ

  - This is the first release of `@keystonejs/*` packages (previously `@keystone-alpha/*`).
  - All packages in the `@keystone-alpha` namespace are now available in the `@keystonejs` namespace, starting at version `5.0.0`.
  - To upgrade your project you must update any `@keystone-alpha/*` dependencies in `package.json` to point to `"@keystonejs/*": "^5.0.0"` and update any `require`/`import` statements in your code.

### Patch Changes

- Updated dependencies [[`7b4ed362`](https://github.com/keystonejs/keystone-5/commit/7b4ed3623f5774d7783c39962bfa1ce97938e310)]:
  - @keystonejs/fields@5.0.0
  - @keystonejs/session@5.0.0

# @keystone-alpha/auth-password

## 1.0.6

### Patch Changes

- Updated dependencies [[`effc1f63`](https://github.com/keystonejs/keystone-5/commit/effc1f639d5824720b7a9d82c2ee881d77acb901)]:
  - @keystone-alpha/fields@15.0.0

## 1.0.5

### Patch Changes

- Updated dependencies [[`6d7d0df0`](https://github.com/keystonejs/keystone-5/commit/6d7d0df0515c3aa21c7d24db17919ddbb5701ce9)]:
  - @keystone-alpha/fields@14.0.0

## 1.0.4

- Updated dependencies [4e6a574d](https://github.com/keystonejs/keystone-5/commit/4e6a574d):
  - @keystone-alpha/fields@13.0.0

## 1.0.3

### Patch Changes

- [9b532072](https://github.com/keystonejs/keystone-5/commit/9b532072): Rename Keystone to KeystoneJS in docs where possible in docs

## 1.0.2

- Updated dependencies [9ade2b2d](https://github.com/keystonejs/keystone-5/commit/9ade2b2d):
  - @keystone-alpha/fields@12.0.0

## 1.0.1

- Updated dependencies [89c0d7e9](https://github.com/keystonejs/keystone-5/commit/89c0d7e9):
- Updated dependencies [a8e9378d](https://github.com/keystonejs/keystone-5/commit/a8e9378d):
  - @keystone-alpha/fields@11.0.0

## 1.0.0

### Major Changes

- [e42fdb4a](https://github.com/keystonejs/keystone-5/commit/e42fdb4a): Makes the password auth strategy its own package.
  Previously: `const { Keystone, PasswordAuthStrategy } = require('@keystone-alpha/keystone');`
  After change: `const { PasswordAuthStrategy } = require('@keystone-alpha/auth-password');`
