const { PrismaAdapter, PrismaListAdapter, PrismaFieldAdapter } = require('./lib/adapter-prisma');

module.exports = { PrismaAdapter, PrismaListAdapter, PrismaFieldAdapter };
