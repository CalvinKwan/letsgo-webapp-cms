const {
  MongooseAdapter,
  MongooseListAdapter,
  MongooseFieldAdapter,
} = require('./lib/adapter-mongoose');
module.exports = { MongooseAdapter, MongooseListAdapter, MongooseFieldAdapter };
