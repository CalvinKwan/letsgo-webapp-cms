<!--[meta]
section: api
subSection: utilities
title: Session
[meta]-->

# Session

> This is the last active development release of this package as **Keystone 5** is now in a 6 to 12 month active maintenance phase. For more information please read our [Keystone 5 and beyond](https://github.com/keystonejs/keystone-5/issues/21) post.

<!-- TODO -->

This package contains functions to assist with setting up session management in your KeystoneJS system.
