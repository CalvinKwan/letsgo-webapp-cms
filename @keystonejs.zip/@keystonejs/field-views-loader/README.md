<!--[meta]
title: Field Views Loader
[meta]-->

# Field Views Loader

> This is the last active development release of this package as **Keystone 5** is now in a 6 to 12 month active maintenance phase. For more information please read our [Keystone 5 and beyond](https://github.com/keystonejs/keystone-5/issues/21) post.

This packages contains a [webpack loader](https://webpack.js.org/api/loaders) which makes the field type UI components available to the Admin UI.

This package is an internal helper package used by Keystone. It contains a [webpack loader](https://webpack.js.org/api/loaders) which makes the field type UI components available to the Admin UI.

You should probably not use this directly in your Keystone projects.
