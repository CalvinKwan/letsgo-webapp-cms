const { AppVersionProvider, appVersionMiddleware } = require('./lib/app-version');

module.exports = { AppVersionProvider, appVersionMiddleware };
