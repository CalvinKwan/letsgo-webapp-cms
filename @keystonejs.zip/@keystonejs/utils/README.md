<!--[meta]
title: Utilities
[meta]-->

# Utilities

> This is the last active development release of this package as **Keystone 5** is now in a 6 to 12 month active maintenance phase. For more information please read our [Keystone 5 and beyond](https://github.com/keystonejs/keystone-5/issues/21) post.

This package is an internal Keystone package which contains various helper functions which are used throughout the monorepo.

You should probably not use this directly in your Keystone projects.
