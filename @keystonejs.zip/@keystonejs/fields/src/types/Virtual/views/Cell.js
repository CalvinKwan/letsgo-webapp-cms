import React from 'react';
import PrettyData from '../prettyData';

export default ({ data }) => {
  return <PrettyData data={data} />;
};
